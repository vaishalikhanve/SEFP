package com.example.minni.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Activity2 extends AppCompatActivity {
    DatabaseHelper myDb;
    EditText e1,e2,e3,e4;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        myDb=new DatabaseHelper(this);


        e1 = (EditText)findViewById(R.id.e1);
        e2 = (EditText)findViewById(R.id.e2);
        e3 = (EditText)findViewById(R.id.e3);
        e4 = (EditText)findViewById(R.id.e4);


        b1=(Button)findViewById(R.id.b1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isInserted = myDb.insertData(e1.getText().toString(), e2.getText().toString(), e3.getText().toString(),e4.getText().toString());

                if(isInserted==true)
                {
                    Toast.makeText(Activity2.this,"Data is inserted",Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Activity2.this, Activity5.class));
                }
                else
                {
                    Toast.makeText(Activity2.this,"Data not inserted",Toast.LENGTH_LONG).show();
                }

            }


            });

    }
}
